## Home page
Logged in             |  Logged out
:-------------------------:|:-------------------------:
![](https://i.imgur.com/FIZFDEI.png)  |  ![](https://i.imgur.com/NYnkv91.png)
## Login and Register pages
Login             |  Register
:-------------------------:|:-------------------------:
![](https://i.imgur.com/cUL73Sa.png)  |  ![](https://i.imgur.com/6zyuO0h.png)